<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Adam J Burcher</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.min.css" rel="stylesheet">
</head>

<body>

  <!--Main Navigation-->
  <header>

    <!-- Navbar -->
    <nav class="navbar fixed-top navbar-expand-lg rgba-purple-strong scrolling-navbar">
      <div class="container">

        </div>

      </div>
    </nav>
    <!-- Navbar -->

  </header>
  <!--Main Navigation-->

  <!--Main layout-->
  <main class="mt-5 pt-5">
    <div class="container">

      <!--Section: Jumbotron-->
      <section class="card wow fadeIn" id="intro" style="background-image: url(personalContent/personalImageLarge.png); background-size: 1110px;"  >

        <!-- Content -->
        <div class="card-body text-black text-center py-5 px-5 my-5">

          <h1 class="mb-4">
            <strong><a href="/index.html" target="_blank">Portfolio of Adam J Burcher</a></strong>
          </h1>
          
          <p>
            <strong>"He's a credit to his family" - His Teacher, 2014</strong>
          </p>
          
          <p class="mb-4">
            <strong>He's a picker, He's a grinner. He's a lover, and he's a sinner. He plays his music in the sun.
            He's going to get sued for copyright laws on this song.</strong>
          </p>
          
          <a target="_blank" href="https://www.facebook.com/adamburcher.97/" class="btn btn-outline-black btn-lg">Check his Facebook
          </a>

        </div>
        <!-- Content -->
      </section>
      <!--Section: Jumbotron-->
      <section class="pt-5">
        
        
      <div class="wow fadeIn">
      <h2 class="h1 text-center mb-5">How's this for an Ideal Job?</h2>
      <p class="text-center">Here's a brief questionnaire I answered in regards to my ideal job. </p>
      <p class="text-center">Working Hours: Minimum 30 per week </p>
      <p class="text-center">Pay: Livable</p>
      <p class="text-center">Location: As long as I can live with my friends</p>
      <p class="text-center">Flexibility: I'd like to work from home occasionally?</p>
      <p class="text-center">Variety of Work: It can vary from project to project, but I'd really just like to be writing programs</p>
      <p class="text-center">Skills Required: Whatever language I'm programming in</p>
      <p class="text-center">Amount of Creativity: Minimal. Someone else can do the creative stuff</p>
      <p class="text-center">Prospects for Travel: I'm not too concerned</p>
      <p class="text-center">Level of Teamwork: Very Minimal. I prefer working by myself when I'm writing programs</p>
      <p class="text-center">Amount of Interaction with General Public: Some is okay, although I feel like that would be largely unnecessary</p>
      <p class="text-center">Opportunities for Personal Development: I see a big need. I really would like support on any personal projects I may have</p>  
      <p class="text-center">Todd Howard, hit me up</p>
      </div>
      
      
      </section>
      </main>
  <!--Footer-->
  <footer class="page-footer text-center font-small mdb-color darken-2 mt-4 wow fadeIn">

    <!--Call to action-->
    <div class="pt-4">
      <a class="btn btn-outline-white" href="Adam Burcher Resume.docx" download role="button">Download his Resume
        <i class="fas fa-download ml-2"></i>
      </a>
    </div>
    <!--/.Call to action-->

    <hr class="my-4">

    <!-- Social icons -->
    <div class="pb-4">
      <a href="https://www.facebook.com/adamburcher.97" target="_blank">
        <i class="fab fa-facebook-f mr-3"></i>
      </a>
    </div>
    <!-- Social icons -->

    <!--Copyright-->
    <div class="footer-copyright py-3">
      © 2019 Copyright:
      <a href="https://mdbootstrap.com/education/bootstrap/" target="_blank"> MDBootstrap.com </a>
      <br />Template from MDBootstrap.com
    </div>
    <!--/.Copyright-->

  </footer>
  <!--/.Footer-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Initializations -->
  <script type="text/javascript">
    // Animations initialization
    new WOW().init();

  </script>
      </body>
</html>