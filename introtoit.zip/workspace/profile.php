<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Adam J Burcher</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.min.css" rel="stylesheet">
</head>

<body>

  <!--Main Navigation-->
  <header>

    <!-- Navbar -->
    <nav class="navbar fixed-top navbar-expand-lg rgba-purple-strong scrolling-navbar">
      <div class="container">

        </div>

      </div>
    </nav>
    <!-- Navbar -->

  </header>
  <!--Main Navigation-->

  <!--Main layout-->
  <main class="mt-5 pt-5">
    <div class="container">

      <!--Section: Jumbotron-->
      <section class="card wow fadeIn" id="intro" style="background-image: url(personalContent/personalImageLarge.png); background-size: 1110px;"  >

        <!-- Content -->
        <div class="card-body text-black text-center py-5 px-5 my-5">

          <h1 class="mb-4">
            <strong><a href="/index.html" target="_blank">Portfolio of Adam J Burcher</a></strong>
          </h1>
          
          <p>
            <strong>"He's a credit to his family" - His Teacher, 2014</strong>
          </p>
          
          <p class="mb-4">
            <strong>He's a picker, He's a grinner. He's a lover, and he's a sinner. He plays his music in the sun.
            He's going to get sued for copyright laws on this song.</strong>
          </p>
          
          <a target="_blank" href="https://www.facebook.com/adamburcher.97/" class="btn btn-outline-black btn-lg">Check his Facebook
          </a>

        </div>
        <!-- Content -->
      </section>
      <!--Section: Jumbotron-->
      <section class="pt-5">
        
        
      <div class="wow fadeIn">
      <h2 class="h1 text-center mb-5">As if Personal Info wasn't enough</h2>
      <p class="text-center">Well I just quickly took a MBTI personality test on <a href="16personalities.com">16 Personalities</a> and that said I'm INFJ. Also I hit up my boy Vark at
      <a href="http://vark-learn.com/the-vark-questionnaire/"> Vark.com</a> and he gave me a questionnaire to answer. That gave me 
      a ranking across four different values. I scored 4/10 for visual learning, 5/10 for aural learning, 2/10 for written learning,
      and 10/10 for kinesthetic learning. I also completed a quiz titled Interpersonal Skills Self-Assessment which can be found <a href="https://www.skillsyouneed.com/ls/index.php/343479/lang/en/newtest/Y"> here.</a>
      That one told me that my interpersonal skills are slightly below average with a score of 48%.</p></br>
      <p class="text-center">After taking these tests I believe that the MBTI test is accurate, Vark is accurate too, and the third one could be accurate too,
      although in my arrogance I want to say it's wrong. In the third test, my weakest point was group work. This is largely because I'm not confident about alot of things
      and so in turn, I generally feel that I don't have much to contribute to conversations. If the conversation turns to something that I'm already confident in, then I can 
      light up a room. In choosing a group, I'd like to be with people who can carry a conversation. I don't want to talk much if I don't have to, and when I do have input, 
      it will be relevant.</p>
      </div>
      
      
      </section>
      </main>
  <!--Footer-->
  <footer class="page-footer text-center font-small mdb-color darken-2 mt-4 wow fadeIn">

 <!--Call to action-->
    <div class="pt-4">
      <a class="btn btn-outline-white" href="Adam Burcher Resume.docx" download role="button">Download his Resume
        <i class="fas fa-download ml-2"></i>
      </a>
    </div>
    <!--/.Call to action-->

    <hr class="my-4">

    <!-- Social icons -->
    <div class="pb-4">
      <a href="https://www.facebook.com/adamburcher.97" target="_blank">
        <i class="fab fa-facebook-f mr-3"></i>
      </a>
    </div>
    <!-- Social icons -->

    <!--Copyright-->
    <div class="footer-copyright py-3">
      © 2019 Copyright:
      <a href="https://mdbootstrap.com/education/bootstrap/" target="_blank"> MDBootstrap.com </a>
      <br />Template from MDBootstrap.com
    </div>
    <!--/.Copyright-->

  </footer>
  <!--/.Footer-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Initializations -->
  <script type="text/javascript">
    // Animations initialization
    new WOW().init();

  </script>
      </body>
</html>