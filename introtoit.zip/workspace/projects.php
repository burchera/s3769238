<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Adam J Burcher</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.min.css" rel="stylesheet">
</head>

<body>

  <!--Main Navigation-->
  <header>

    <!-- Navbar -->
    <nav class="navbar fixed-top navbar-expand-lg rgba-purple-strong scrolling-navbar">
      <div class="container">

        </div>

      </div>
    </nav>
    <!-- Navbar -->

  </header>
  <!--Main Navigation-->

  <!--Main layout-->
  <main class="mt-5 pt-5">
    <div class="container">

      <!--Section: Jumbotron-->
      <section class="card wow fadeIn" id="intro" style="background-image: url(personalContent/personalImageLarge.png); background-size: 1110px;"  >

        <!-- Content -->
        <div class="card-body text-black text-center py-5 px-5 my-5">

          <h1 class="mb-4">
            <strong><a href="/index.html" target="_blank">Portfolio of Adam J Burcher</a></strong>
          </h1>
          
          <p>
            <strong>"He's a credit to his family" - His Teacher, 2014</strong>
          </p>
          
          <p class="mb-4">
            <strong>He's a picker, He's a grinner. He's a lover, and he's a sinner. He plays his music in the sun.
            He's going to get sued for copyright laws on this song.</strong>
          </p>
          
          <a target="_blank" href="https://www.facebook.com/adamburcher.97/" class="btn btn-outline-black btn-lg">Check his Facebook
          </a>

        </div>
        <!-- Content -->
      </section>
      <!--Section: Jumbotron-->
      <section class="pt-5">
      <div class="container">
        <div class="row">
          <div class="col-sm"><h3 class="h3 text-center mb-5">Top Secret Project Frank</h3></div>
        </div>
        <div class="row text-center">Recently when I was living with my sister, I got to use a Google Home device.
          I only really used it to listen to music, but I noticed that talking to it, felt like talking to a robot.
          I think that's to be expected because that's what is happening, I was talking to a robot.
          I had to slow my speech down, enunciate words properly, start sentences with "Okay Google...",
          and I could only say certain things, because it had limited functions. Not to mention the fact that
          if I’m having a conversation with a friend about that new shirt, I saw that I might like to buy,
          Google Home is going to hear that and start giving me ads for shirts for the next month. Personally,
          I’m not a fan of that. Privacy is a bit out the window in that regard, but the biggest thing is that I
          don’t need advertisements for other shirts, nor do I want them; I was talking about a specific shirt. 
          Enter Frank. An Artificial Intelligence System of my own creation which is better in the aspects that
          I mentioned about Google Home. Talking to Frank should feel like a regular conversation, as if talking
          to a friend. The name Frank comes from my father, also Frank. He was a very big inspiration to me, but
          he passed away two weeks before my 21st birthday. For as long as I knew him, he was always trying to help
          people and get better at helping people. He learnt how to talk to people, so that he could talk better to people.
          I want to write Frank as a program that’s better than Google Home and Alexa. As a finished product
          he’s going to help a lot of people, but before then I want him to help one person.
        </div>
        </br>
        <div class="row">
          <div class="col-sm text-right"><strong>The Skills</strong></div>
          <div class="col-sm text-center"><strong>The Hardware</strong></div>
          <div class="col-sm text-left"><strong>The Outcome</strong></div>
        </div>
        <div class="row">
          <div class="col-sm text-right">Due to the nature of Frank, I’m going to need to learn a few things. Speech Recognition
            and Machine Learning will be the two primary learning points. Frank needs to listen to the user, recognise what they’re saying,
            and respond accordingly. Additionally, Frank will be listening to the user even when the user isn’t specifically talking to Frank.
            This is so that Frank can learn how that user talks naturally, their speech patterns, enunciations, and subtleties in their dialect.
            When I talk to a friend, I can talk fast, or slow, I can mumble or shout, my friend can almost always understand what I’m saying.
            I want Frank to be able to do the same. Additionally, I want him to learn how people deal with emotions. For instance, if you tend
            to watch movies and eat delivery pizza when you’re sad, Frank can learn that watching movies and delivery pizza can be a solution
            for another time when Frank learns that you’re feeling sad. Naturally he’ll also need to learn how to recognise sadness in this example,
            I think the simplest way would be to check multiple conditions. If you’re talking quieter than normal can be a starting hint.
            Perhaps Frank heard you talking about some bad news to a friend earlier, the friend left, and you’re still talking quietly, he can ask
            “You seem to be sad about something, can I suggest you watch this movie whilst I order a pizza for you?” The user then naturally gets
            a choice to respond with yes, no, or maybe I’ll watch a movie, but don’t order the pizza. Either way Frank has then helped the user to
            deal with their sadness in this way. I will need to learn more than just Speech Recognition and Machine Learning for this, but those are
            the two major points. Another issue with Google Home and Alexa devices is targeted advertising. If you talk about going on holiday one time,
            then you’ll be getting ads on the computer for holiday destinations for the next month.
          </div>
          <div class="col-sm text-center">Frank is going to be a large program. Firstly, he needs a considerable amount of data storage space to store
            his knowledge on the user’s speech patterns. Secondly, more data storage to store his voice. He’s going to be able to respond by voice,
            to whatever the user says to him, and so he’ll need voice lines for everything he can say. He’ll also need an internet connection at any given moment.
            Since the required storage space won’t be available locally for each user, Frank will need to be able to connect to the offsite data banks.
            For the user, they’ll need a central speaker unit. I’m thinking the user might need more than one. Like how a speaker system can have a central bass unit,
            and subsequent left and right speakers, Frank could use extra speakers to get more coverage to listen to the user.
          </div>
          <div class="col-sm text-left">I want to develop Frank to work well with one person before looking to multiple people. It’ll be easier for debugging and error prevention that way.
            Additionally, that will allow me to teach Frank to learn how to deal with one person. I believe Frank is necessary for people today.
            I believe people need to be able to talk about their problems more. Counsellors are generally expensive, and its unreasonable to expect friends to always be available to talk.
            I believe that having Frank around to learn how to talk to people and help them, will be able to help people considerably. On another point,
            Frank won’t be sharing his knowledge of individual people to anyone else. This means no targeted advertising. Frank will be able to hold your
            credit card details for ease of access. If you’re sad and asking him to order a pizza, you won’t want to read out your card details to him each time.
            However, as a security measure, you will need to verbally approve him using it each time. Frank is always listening to the user, in their daily interactions,
            in order to learn how to converse with the user more efficiently. Frank is going to be my masterpiece,
            and regardless of whether it makes it past this assignment, I will continue to work on him.
          </div>
        </div>
      </div>
      </section>
      </main>
  <!--Footer-->
  <footer class="page-footer text-center font-small mdb-color darken-2 mt-4 wow fadeIn">

    <!--Call to action-->
    <div class="pt-4">
      <a class="btn btn-outline-white" href="Adam Burcher Resume.docx" download role="button">Download his Resume
        <i class="fas fa-download ml-2"></i>
      </a>
    </div>
    <!--/.Call to action-->

    <hr class="my-4">

    <!-- Social icons -->
    <div class="pb-4">
      <a href="https://www.facebook.com/adamburcher.97" target="_blank">
        <i class="fab fa-facebook-f mr-3"></i>
      </a>
    </div>
    <!-- Social icons -->

    <!--Copyright-->
    <div class="footer-copyright py-3">
      © 2019 Copyright:
      <a href="https://mdbootstrap.com/education/bootstrap/" target="_blank"> MDBootstrap.com </a>
      <br />Template from MDBootstrap.com
    </div>
    <!--/.Copyright-->

  </footer>
  <!--/.Footer-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Initializations -->
  <script type="text/javascript">
    // Animations initialization
    new WOW().init();

  </script>
      </body>
</html>